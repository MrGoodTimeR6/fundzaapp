package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Backup;

public class BackupController {
    public void realizarBackup() {
        System.out.println("Iniciando o backup...");
        Backup.realizarBackup();
    }
}
