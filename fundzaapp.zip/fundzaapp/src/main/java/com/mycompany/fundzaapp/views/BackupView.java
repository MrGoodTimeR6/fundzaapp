package com.mycompany.fundzaapp.views;

import javax.swing.*;
import java.awt.*;

public class BackupView extends JFrame {
    public BackupView() {
        setTitle("Backup de Segurança");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10, 10));

        JPanel autoBackupPanel = new JPanel();
        autoBackupPanel.setBorder(BorderFactory.createTitledBorder("Backup Automático"));
        JCheckBox chkAutoBackup = new JCheckBox("Ativar backups regulares");
        autoBackupPanel.add(chkAutoBackup);

        JButton btnManualBackup = new JButton("Fazer Backup Manual");

        add(autoBackupPanel, BorderLayout.CENTER);
        add(btnManualBackup, BorderLayout.SOUTH);

        setVisible(true);
    }
}
