package com.mycompany.fundzaapp.model;

public class Relatorio {
    private String titulo;
    private String conteudo;

    public Relatorio(String titulo, String conteudo) {
        this.titulo = titulo;
        this.conteudo = conteudo;
    }

    public void gerarRelatorioPDF() {
        System.out.println("Gerando relatório PDF...");
        // Implementar JasperReports ou biblioteca PDFBox
    }

    public void exportarExcel() {
        System.out.println("Exportando relatório para Excel...");
        // Implementar exportação usando Apache POI
    }

    // Getters e Setters
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getConteudo() { return conteudo; }
    public void setConteudo(String conteudo) { this.conteudo = conteudo; }
}
