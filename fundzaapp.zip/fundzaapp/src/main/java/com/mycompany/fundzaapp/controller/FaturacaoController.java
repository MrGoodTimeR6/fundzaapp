package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Database;
import com.mycompany.fundzaapp.model.Venda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

public class FaturacaoController {
    public void registrarVenda(Venda venda) {
        String sql = "INSERT INTO vendas (produto_id, quantidade, total, data_venda) VALUES (?, ?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, venda.getProdutoId());
            stmt.setInt(2, venda.getQuantidade());
            stmt.setDouble(3, venda.getTotal());
            stmt.setDate(4, new java.sql.Date(venda.getDataVenda().getTime()));
            stmt.executeUpdate();
            System.out.println("Venda registrada com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao registrar venda.");
        }
    }
}
