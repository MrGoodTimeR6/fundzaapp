package com.mycompany.fundzaapp.views;

import com.mycompany.fundzaapp.model.Database;
import com.mycompany.fundzaapp.model.Usuario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class ClientesView extends JFrame {

    public ClientesView(Usuario usuario) {
        setTitle("Clientes - Sistema de Gestão");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Gestão de Clientes", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitle.setForeground(new Color(0, 35, 102));
        add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(2, 2, 20, 20));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnNovoCliente = new JButton("Novo Cliente");
        configureButton(btnNovoCliente);
        btnNovoCliente.addActionListener(e -> cadastrarNovoCliente());
        centerPanel.add(btnNovoCliente);

        JButton btnListaClientes = new JButton("Lista de Clientes");
        configureButton(btnListaClientes);
        btnListaClientes.addActionListener(e -> mostrarListaClientes());
        centerPanel.add(btnListaClientes);

        JButton btnHistoricoCompras = new JButton("Histórico de Compras");
        configureButton(btnHistoricoCompras);
        btnHistoricoCompras.addActionListener(e -> mostrarHistoricoCompras(usuario));
        centerPanel.add(btnHistoricoCompras);

        JButton btnVoltar = new JButton("Voltar");
        configureButton(btnVoltar);
        btnVoltar.addActionListener(e -> new DashboardView(usuario));
        centerPanel.add(btnVoltar);

        add(centerPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void configureButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(15, 169, 88));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(13, 150, 78));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(15, 169, 88));
            }
        });
    }

    private void cadastrarNovoCliente() {
        JTextField nomeField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField telefoneField = new JTextField();

        Object[] message = {
            "Nome:", nomeField,
            "Email:", emailField,
            "Telefone:", telefoneField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Novo Cliente", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = Database.getConnection()) {
                String sql = "INSERT INTO clientes (nome, email, telefone) VALUES (?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, nomeField.getText());
                stmt.setString(2, emailField.getText());
                stmt.setString(3, telefoneField.getText());
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar cliente.");
            }
        }
    }

    private void mostrarListaClientes() {
        JFrame frame = new JFrame("Lista de Clientes");
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM clientes";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            JTable table = new JTable(buildTableModel(rs));
            frame.add(new JScrollPane(table), BorderLayout.CENTER);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar lista de clientes.");
        }

        frame.setVisible(true);
    }

    private void mostrarHistoricoCompras(Usuario usuario) {
        JFrame frame = new JFrame("Histórico de Compras");
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM vendas WHERE cliente_id IN (SELECT id FROM clientes)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            JTable table = new JTable(buildTableModel(rs));
            frame.add(new JScrollPane(table), BorderLayout.CENTER);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar histórico de compras.");
        }

        frame.setVisible(true);
    }

    private static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();

        int columnCount = metaData.getColumnCount();

        Vector<String> columnNames = new Vector<>();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> row = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                row.add(rs.getObject(columnIndex));
            }
            data.add(row);
        }

        return new DefaultTableModel(data, columnNames);
    }
}
