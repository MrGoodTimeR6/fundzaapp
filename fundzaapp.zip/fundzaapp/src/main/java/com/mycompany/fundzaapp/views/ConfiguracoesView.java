package com.mycompany.fundzaapp.views;

import javax.swing.*;
import java.awt.*;

public class ConfiguracoesView extends JFrame {
    public ConfiguracoesView() {
        setTitle("Configurações do Sistema");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JLabel lblInfo = new JLabel("Aqui você pode ajustar configurações gerais do sistema.");
        add(lblInfo);

        setVisible(true);
    }
}
