package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ConfiguracoesController {
    public void atualizarSenha(int usuarioId, String novaSenha) {
        String sql = "UPDATE usuarios SET password = ? WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, novaSenha);
            stmt.setInt(2, usuarioId);
            stmt.executeUpdate();
            System.out.println("Senha atualizada com sucesso.");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Erro ao atualizar senha.");
        }
    }
}
