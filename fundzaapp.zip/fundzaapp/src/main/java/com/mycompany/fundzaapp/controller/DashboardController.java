package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class DashboardController {

    public int totalVendasHoje() {
        String sql = "SELECT COUNT(*) AS total FROM vendas WHERE DATE(data_venda) = CURDATE()";
        return contarRegistros(sql);
    }

    public int totalClientesAtivos() {
        String sql = "SELECT COUNT(*) AS total FROM clientes WHERE ativo = 1";
        return contarRegistros(sql);
    }

    public int totalLivrosEstoque() {
        String sql = "SELECT SUM(quantidade) AS total FROM produtos";
        return contarRegistros(sql);
    }

    private int contarRegistros(String sql) {
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt("total");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
