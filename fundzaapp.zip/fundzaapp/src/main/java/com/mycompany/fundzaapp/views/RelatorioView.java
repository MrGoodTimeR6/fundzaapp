package com.mycompany.fundzaapp.views;


import com.mycompany.fundzaapp.model.Database;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Objects;

public class RelatorioView extends JFrame {
    public RelatorioView() {
        setTitle("Relatórios - Sistema de Gestão");
        setSize(900, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel header = new JPanel();
        header.setBackground(new Color(0, 35, 102));
        JLabel lblTitle = new JLabel("Geração de Relatórios");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);
        header.add(lblTitle);
        add(header, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 20, 20));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnRelatorioVendas = createMenuButton("Relatório de Vendas");
        JButton btnRelatorioAutorais = createMenuButton("Relatório de Direitos Autorais");

        btnRelatorioVendas.addActionListener(e -> exibirRelatorio("Vendas"));
        btnRelatorioAutorais.addActionListener(e -> exibirRelatorio("Direitos Autorais"));

        centerPanel.add(btnRelatorioVendas);
        centerPanel.add(btnRelatorioAutorais);

        add(centerPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(15, 169, 88));
        button.setForeground(Color.WHITE);
        return button;
    }

    private void exibirRelatorio(String tipoRelatorio) {
        String query = gerarConsulta(tipoRelatorio);

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            DefaultTableModel model = criarModeloTabela(rs);
            JTable tabela = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(tabela);

            JPanel painel = new JPanel(new BorderLayout());
            painel.add(scrollPane, BorderLayout.CENTER);

            JOptionPane.showMessageDialog(this, painel, "Relatório - " + tipoRelatorio, JOptionPane.PLAIN_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar dados do banco de dados: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private String gerarConsulta(String tipoRelatorio) {
        return switch (tipoRelatorio) {
            case "Vendas" -> """
                    SELECT r.id, r.nome_relatorio, u.username AS gerado_por, r.data_geracao
                    FROM relatorios r
                    JOIN usuarios u ON r.gerado_por = u.id
                    WHERE r.nome_relatorio LIKE '%Vendas%'
                    """;
            case "Direitos Autorais" -> """
                    SELECT r.id, r.nome_relatorio, u.username AS gerado_por, r.data_geracao
                    FROM relatorios r
                    JOIN usuarios u ON r.gerado_por = u.id
                    WHERE r.nome_relatorio LIKE '%Autorais%'
                    """;
            default -> null;
        };
    }

    private DefaultTableModel criarModeloTabela(ResultSet rs) throws SQLException {
        String[] colunas = {"ID", "Nome do Relatório", "Gerado Por", "Data de Geração"};
        DefaultTableModel model = new DefaultTableModel(colunas, 0);

        while (rs.next()) {
            int id = rs.getInt("id");
            String nomeRelatorio = rs.getString("nome_relatorio");
            String geradoPor = rs.getString("gerado_por");
            Timestamp dataGeracao = rs.getTimestamp("data_geracao");

            model.addRow(new Object[]{id, nomeRelatorio, geradoPor, dataGeracao});
        }

        return model;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RelatorioView::new);
    }
}
