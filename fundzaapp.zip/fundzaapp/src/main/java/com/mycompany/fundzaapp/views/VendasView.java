package com.mycompany.fundzaapp.views;

import com.mycompany.fundzaapp.model.Usuario;
import com.mycompany.fundzaapp.model.Database;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class VendasView extends JFrame {
    private final Usuario usuario;

    public VendasView(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Vendas - Sistema de Gestão");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Gestão de Vendas", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitle.setForeground(new Color(0, 35, 102));
        add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(2, 2, 20, 20));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnNovaVenda = new JButton("Nova Venda");
        configureButton(btnNovaVenda);
        btnNovaVenda.addActionListener(e -> novaVenda());
        centerPanel.add(btnNovaVenda);

        JButton btnHistorico = new JButton("Histórico de Vendas");
        configureButton(btnHistorico);
        btnHistorico.addActionListener(e -> mostrarHistorico());
        centerPanel.add(btnHistorico);

        JButton btnResumo = new JButton("Resumo de Vendas");
        configureButton(btnResumo);
        btnResumo.addActionListener(e -> mostrarResumo());
        centerPanel.add(btnResumo);

        JButton btnVoltar = new JButton("Voltar");
        configureButton(btnVoltar);
        btnVoltar.addActionListener(e -> new DashboardView(usuario));
        centerPanel.add(btnVoltar);

        add(centerPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void novaVenda() {
    JFrame frame = new JFrame("Nova Venda");
    frame.setSize(400, 300);
    frame.setLayout(new GridLayout(4, 2, 10, 10));
    frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    JTextField clienteIdField = new JTextField();
    JTextField totalField = new JTextField();

    frame.add(new JLabel("ID do Cliente:"));
    frame.add(clienteIdField);
    frame.add(new JLabel("Total (MZN):"));
    frame.add(totalField);

    JButton btnSalvar = new JButton("Salvar");
    btnSalvar.addActionListener(e -> {
        try {
            String clienteIdText = clienteIdField.getText().trim();
            if (clienteIdText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "O ID do cliente não pode estar vazio!");
                return;
            }
            int clienteId = Integer.parseInt(clienteIdText);

            String totalText = totalField.getText().trim();
            if (totalText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "O valor total não pode estar vazio!");
                return;
            }
            double total = Double.parseDouble(totalText);

            salvarVenda(clienteId, total);
            frame.dispose(); 
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Dados inválidos! Por favor, insira valores numéricos corretos.");
        }
    });
    frame.add(btnSalvar);

    frame.setVisible(true);
}


    private void salvarVenda(int clienteId, double total) {
    try (Connection conn = Database.getConnection()) {
        String verificaClienteSQL = "SELECT COUNT(*) FROM clientes WHERE id = ?";
        PreparedStatement stmtVerificaCliente = conn.prepareStatement(verificaClienteSQL);
        stmtVerificaCliente.setInt(1, clienteId);
        ResultSet rs = stmtVerificaCliente.executeQuery();
        
        if (rs.next() && rs.getInt(1) > 0) {
            String sql = "INSERT INTO vendas (usuario_id, cliente_id, total) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuario.getId());
            stmt.setInt(2, clienteId);
            stmt.setDouble(3, total);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Venda salva com sucesso!");
        } else {
            JOptionPane.showMessageDialog(this, "Cliente não encontrado! Verifique o ID do cliente.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Erro ao salvar a venda.");
    }
}


    private void mostrarHistorico() {
        JFrame frame = new JFrame("Histórico de Vendas");
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM vendas WHERE usuario_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuario.getId());
            ResultSet rs = stmt.executeQuery();

            JTable table = new JTable(buildTableModel(rs));
            frame.add(new JScrollPane(table), BorderLayout.CENTER);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar histórico de vendas.");
        }

        frame.setVisible(true);
    }

    private void mostrarResumo() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT COUNT(*) AS total_vendas, SUM(total) AS valor_total FROM vendas WHERE usuario_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuario.getId());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int totalVendas = rs.getInt("total_vendas");
                double valorTotal = rs.getDouble("valor_total");

                JOptionPane.showMessageDialog(this, 
                    "Total de Vendas: " + totalVendas + "\n" +
                    "Valor Total: MZN " + valorTotal);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar resumo de vendas.");
        }
    }

    private void configureButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(15, 169, 88));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(13, 150, 78));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(15, 169, 88));
            }
        });
    }

    private static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();

        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> row = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                row.add(rs.getObject(columnIndex));
            }
            data.add(row);
        }

        return new DefaultTableModel(data, columnNames);
    }
}
