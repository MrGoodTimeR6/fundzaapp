package com.mycompany.fundzaapp.views;

import com.mycompany.fundzaapp.model.Database;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StockView extends JFrame {
    private final DefaultTableModel tableModel;

    public StockView() {
        setTitle("Gestão de Estoque");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Gestão de Estoque", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitle.setOpaque(true);
        lblTitle.setBackground(new Color(0, 35, 102));
        lblTitle.setForeground(Color.WHITE);
        add(lblTitle, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnEntrada = createButton("Registrar Entrada de Mercadoria", e -> registrarEntrada());
        JButton btnSaida = createButton("Registrar Saída de Mercadoria", e -> registrarSaida());
        JButton btnUpload = createButton("Upload Excel", e -> uploadExcel());

        buttonPanel.add(btnEntrada);
        buttonPanel.add(btnSaida);
        buttonPanel.add(btnUpload);
        add(buttonPanel, BorderLayout.WEST);

        tableModel = new DefaultTableModel(new String[]{"ID", "Nome", "Descrição", "Preço", "Quantidade"}, 0);
        JTable table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData();
        setVisible(true);
    }

    private JButton createButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        button.addActionListener(action);
        return button;
    }

    private void registrarEntrada() {
        String nome = JOptionPane.showInputDialog(this, "Nome do Produto:");
        String descricao = JOptionPane.showInputDialog(this, "Descrição:");
        String precoStr = JOptionPane.showInputDialog(this, "Preço (MZN):");
        String quantidadeStr = JOptionPane.showInputDialog(this, "Quantidade:");

        try {
            double preco = Double.parseDouble(precoStr);
            int quantidade = Integer.parseInt(quantidadeStr);

            try (Connection conn = Database.getConnection()) {
                String sql = "INSERT INTO produtos (nome, descricao, preco, quantidade_estoque) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, nome);
                stmt.setString(2, descricao);
                stmt.setDouble(3, preco);
                stmt.setInt(4, quantidade);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Produto registrado com sucesso!");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void registrarSaida() {
        String idStr = JOptionPane.showInputDialog(this, "ID do Produto:");
        String quantidadeStr = JOptionPane.showInputDialog(this, "Quantidade a Remover:");

        try {
            int id = Integer.parseInt(idStr);
            int quantidade = Integer.parseInt(quantidadeStr);

            try (Connection conn = Database.getConnection()) {
                String sql = "UPDATE produtos SET quantidade_estoque = quantidade_estoque - ? WHERE id = ? AND quantidade_estoque >= ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, quantidade);
                stmt.setInt(2, id);
                stmt.setInt(3, quantidade);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Quantidade removida com sucesso!");
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Quantidade insuficiente ou ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

private void uploadExcel() {
    JFileChooser fileChooser = new JFileChooser();
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        File file = fileChooser.getSelectedFile();
        try (FileInputStream fis = new FileInputStream(file); Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);

            try (Connection conn = Database.getConnection()) {
                String sql = "INSERT INTO produtos (nome, descricao, preco, quantidade_estoque) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);

                for (Row row : sheet) {
                    if (row.getRowNum() == 0) continue; // Skip header row

                    // Lê o nome do produto (String), verificando se a célula não é nula
                    String nome = getStringCellValue(row, 0);

                    // Lê a descrição (String), verificando se a célula não é nula
                    String descricao = getStringCellValue(row, 1);

                    // Lê o preço (verificando se é numérico)
                    double preco = 0.0;
                    Cell precoCell = row.getCell(2);
                    if (precoCell != null && precoCell.getCellType() == CellType.NUMERIC) {
                        preco = precoCell.getNumericCellValue();
                    }

                    // Lê a quantidade de estoque (verificando se é numérica)
                    int quantidade = 0;
                    Cell quantidadeCell = row.getCell(3);
                    if (quantidadeCell != null && quantidadeCell.getCellType() == CellType.NUMERIC) {
                        quantidade = (int) quantidadeCell.getNumericCellValue();
                    }

                    stmt.setString(1, nome);
                    stmt.setString(2, descricao);
                    stmt.setDouble(3, preco);
                    stmt.setInt(4, quantidade);
                    stmt.addBatch();
                }

                stmt.executeBatch();
                JOptionPane.showMessageDialog(this, "Arquivo Excel processado com sucesso!");
                loadData();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao processar o Excel: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}

// Método auxiliar para verificar se a célula é nula e retornar um valor padrão
private String getStringCellValue(Row row, int columnIndex) {
    Cell cell = row.getCell(columnIndex);
    if (cell == null) {
        return ""; // Retorna uma string vazia se a célula for nula
    }
    if (cell.getCellType() == CellType.STRING) {
        return cell.getStringCellValue();
    }
    return ""; // Retorna uma string vazia se o valor não for uma string
}



    private void loadData() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT id, nome, descricao, preco, quantidade_estoque FROM produtos";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getDouble("preco"),
                        rs.getInt("quantidade_estoque")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar dados: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
