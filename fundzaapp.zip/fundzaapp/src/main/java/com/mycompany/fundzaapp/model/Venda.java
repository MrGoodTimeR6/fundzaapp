package com.mycompany.fundzaapp.model;

import java.util.Date;

public class Venda {
    private int id;
    private int produtoId;
    private int quantidade;
    private double total;
    private Date dataVenda;

    public Venda(int id, int produtoId, int quantidade, double total, Date dataVenda) {
        this.id = id;
        this.produtoId = produtoId;
        this.quantidade = quantidade;
        this.total = total;
        this.dataVenda = dataVenda;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getProdutoId() { return produtoId; }
    public void setProdutoId(int produtoId) { this.produtoId = produtoId; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public Date getDataVenda() { return dataVenda; }
    public void setDataVenda(Date dataVenda) { this.dataVenda = dataVenda; }
}
