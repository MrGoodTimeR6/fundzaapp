package com.mycompany.fundzaapp.model;

import java.io.IOException;

public class Backup {
    public static void realizarBackup() {
        try {
            String comando = "mysqldump -u root -ppassword gestao_livraria > backup.sql";
            Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c", comando});
            System.out.println("Backup realizado com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erro ao realizar o backup.");
        }
    }
}
