package com.mycompany.fundzaapp.views;

import javax.swing.*;
import java.awt.*;

public class FaturacaoView extends JFrame {
    public FaturacaoView() {
        setTitle("Faturação - Sistema de Gestão");
        setSize(900, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Header
        JPanel header = new JPanel();
        header.setBackground(new Color(0, 35, 102));
        JLabel lblTitle = new JLabel("Gestão de Faturação");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);
        header.add(lblTitle);
        add(header, BorderLayout.NORTH);

        // Center content
        JPanel centerPanel = new JPanel(new GridLayout(3, 2, 20, 20));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnVendas = createMenuButton("Registrar Vendas");
        JButton btnFacturas = createMenuButton("Gerar Facturas");
        JButton btnRecibos = createMenuButton("Emitir Recibos");
        JButton btnNotasCredito = createMenuButton("Notas de Crédito");
        JButton btnNotasDebito = createMenuButton("Notas de Débito");
        JButton btnCotacoes = createMenuButton("Cotações");

        centerPanel.add(btnVendas);
        centerPanel.add(btnFacturas);
        centerPanel.add(btnRecibos);
        centerPanel.add(btnNotasCredito);
        centerPanel.add(btnNotasDebito);
        centerPanel.add(btnCotacoes);

        add(centerPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(15, 169, 88));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        // Hover Effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(13, 150, 78));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(15, 169, 88));
            }
        });
        return button;
    }
}
