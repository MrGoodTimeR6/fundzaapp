package com.mycompany.fundzaapp.views;

import com.mycompany.fundzaapp.controller.LoginController;
import com.mycompany.fundzaapp.model.Usuario;

import javax.swing.*;
import java.awt.*;

public class LoginView extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public LoginView() {
        setTitle("Login - Fundza App");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelMain = new JPanel(new GridLayout(3, 2, 10, 10));
        panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblUsername = new JLabel("Usuário:");
        txtUsername = new JTextField();
        JLabel lblPassword = new JLabel("Senha:");
        txtPassword = new JPasswordField();

        panelMain.add(lblUsername);
        panelMain.add(txtUsername);
        panelMain.add(lblPassword);
        panelMain.add(txtPassword);

        btnLogin = new JButton("Login");
        btnLogin.addActionListener(e -> realizarLogin());

        JPanel panelButton = new JPanel();
        panelButton.add(btnLogin);

        add(panelMain, BorderLayout.CENTER);
        add(panelButton, BorderLayout.SOUTH);
    }

    private void realizarLogin() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        LoginController loginController = new LoginController();
        Usuario usuario = loginController.autenticarUsuario(username, password);

        if (usuario != null) {
            JOptionPane.showMessageDialog(this, "Login bem-sucedido! Bem-vindo, " + usuario.getUsername());
            this.dispose();
            abrirDashboard(usuario);
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void abrirDashboard(Usuario usuario) {
        new DashboardView(usuario).setVisible(true);
    }
}
