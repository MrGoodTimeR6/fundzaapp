package com.mycompany.fundzaapp;

import com.mycompany.fundzaapp.model.Database;
import com.mycompany.fundzaapp.views.LoginView;

import javax.swing.*;

public class Fundzaapp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                System.out.println("Iniciando o sistema FundzaApp...");

                if (Database.getConnection() == null) {
                    throw new RuntimeException("Não foi possível conectar ao banco de dados.");
                }

                new LoginView().setVisible(true);

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null,
                        "Erro ao iniciar o sistema: " + e.getMessage(),
                        "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
