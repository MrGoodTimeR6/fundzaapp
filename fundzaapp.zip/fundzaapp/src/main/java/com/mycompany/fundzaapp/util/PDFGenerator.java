package com.mycompany.fundzaapp.util;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.IOException;
import java.util.List;

public class PDFGenerator {

    public static void generatePDF(String filePath, String title, List<String> content) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
                contentStream.newLineAtOffset(50, 750);
                contentStream.showText(title);
                contentStream.endText();

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                int yPosition = 720;
                for (String line : content) {
                    if (yPosition < 50) {
                        contentStream.endText();
                        contentStream.close();

                        page = new PDPage(PDRectangle.A4);
                        document.addPage(page);
                        yPosition = 750;
                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 12);
                        contentStream.newLineAtOffset(50, yPosition);
                    }
                    contentStream.newLineAtOffset(0, -15);
                    contentStream.showText(line);
                    yPosition -= 15;
                }
                contentStream.endText();
            }

            document.save(filePath);
            System.out.println("PDF gerado com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
