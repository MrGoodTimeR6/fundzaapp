package com.mycompany.fundzaapp.util;

import javax.swing.*;
import java.awt.*;

public class NotificationUtil {

    public static void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public static void showWarningMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Aviso", JOptionPane.WARNING_MESSAGE);
    }

    public static void showCustomNotification(String title, String message, int messageType) {
        JOptionPane.showMessageDialog(null, message, title, messageType);
    }

    public static void showTimedNotification(String title, String message) {
        JFrame frame = new JFrame();
        frame.setSize(300, 150);
        frame.setLocationRelativeTo(null);
        frame.setUndecorated(true);
        frame.setLayout(new BorderLayout());

        JLabel lblMessage = new JLabel(message, SwingConstants.CENTER);
        lblMessage.setFont(new Font("Arial", Font.PLAIN, 14));
        frame.add(lblMessage, BorderLayout.CENTER);

        frame.setVisible(true);

        new Timer(3000, e -> frame.dispose()).start();
    }
}
