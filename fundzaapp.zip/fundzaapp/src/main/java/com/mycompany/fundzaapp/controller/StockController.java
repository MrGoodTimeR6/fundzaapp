package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Database;
import com.mycompany.fundzaapp.model.Stock;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class StockController {
    public void atualizarEstoque(Stock stock) {
        String sql = "INSERT INTO stock (produto_id, quantidade, tipo) VALUES (?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, stock.getProdutoId());
            stmt.setInt(2, stock.getQuantidade());
            stmt.setString(3, stock.getTipo());
            stmt.executeUpdate();
            System.out.println("Movimento de estoque registrado com sucesso.");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Erro ao atualizar estoque.");
        }
    }
}
