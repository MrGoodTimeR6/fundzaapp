package com.mycompany.fundzaapp.controller;

import com.mycompany.fundzaapp.model.Relatorio;

public class RelatorioController {
    public void gerarRelatorioVendas() {
        Relatorio relatorio = new Relatorio("Relatório de Vendas", "Conteúdo de vendas...");
        relatorio.gerarRelatorioPDF();
    }

    public void exportarRelatorioExcel() {
        Relatorio relatorio = new Relatorio("Relatório de Estoque", "Conteúdo de estoque...");
        relatorio.exportarExcel();
    }
}
