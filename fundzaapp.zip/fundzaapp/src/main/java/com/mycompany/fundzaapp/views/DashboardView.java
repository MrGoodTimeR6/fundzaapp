package com.mycompany.fundzaapp.views;

import com.mycompany.fundzaapp.model.Usuario;

import javax.swing.*;
import java.awt.*;

public class DashboardView extends JFrame {
    public DashboardView(Usuario usuario) {
        setTitle("Dashboard - Sistema de Gestão");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(0, 35, 102));
        menuPanel.setLayout(new GridLayout(7, 1, 10, 10)); // Ajustado para incluir o botão sair
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        // Botão para a tela Início
        JButton btnInicio = new JButton("Início");
        configureButton(btnInicio);
        btnInicio.addActionListener(e -> navigateToInicio(usuario));
        menuPanel.add(btnInicio);

        // Botão para a tela Vendas
        JButton btnVendas = new JButton("Vendas");
        configureButton(btnVendas);
        btnVendas.addActionListener(e -> navigateToVendas(usuario));
        menuPanel.add(btnVendas);

        // Botão para a tela Clientes
        JButton btnClientes = new JButton("Clientes");
        configureButton(btnClientes);
        btnClientes.addActionListener(e -> navigateToClientes(usuario));
        menuPanel.add(btnClientes);

        // Botão para a tela Estoque
        JButton btnEstoque = new JButton("Estoque");
        configureButton(btnEstoque);
        btnEstoque.addActionListener(e -> navigateToEstoque(usuario));
        menuPanel.add(btnEstoque);

        // Botão para a tela Relatórios
        JButton btnRelatorios = new JButton("Relatórios");
        configureButton(btnRelatorios);
        btnRelatorios.addActionListener(e -> navigateToRelatorios(usuario));
        menuPanel.add(btnRelatorios);

        // Botão para a tela Configurações
        JButton btnConfiguracoes = new JButton("Configurações");
        configureButton(btnConfiguracoes);
        btnConfiguracoes.addActionListener(e -> navigateToConfiguracoes(usuario));
        menuPanel.add(btnConfiguracoes);

        // Botão para sair
        JButton btnSair = new JButton("Sair");
        btnSair.setFocusPainted(false);
        btnSair.setBackground(new Color(200, 50, 50));
        btnSair.setForeground(Color.WHITE);
        btnSair.setFont(new Font("Arial", Font.BOLD, 14));
        btnSair.setBorder(BorderFactory.createRaisedBevelBorder());

        btnSair.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Deseja realmente sair?", "Confirmação", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        menuPanel.add(btnSair);

        add(menuPanel, BorderLayout.WEST);

        // Conteúdo central
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(2, 3, 20, 20));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        centerPanel.add(createMetricCard("Vendas Hoje", "245"));
        centerPanel.add(createMetricCard("Clientes Ativos", "120"));
        centerPanel.add(createMetricCard("Livros no Estoque", "980"));

        JLabel lblWelcome = new JLabel("Bem-vindo, " + usuario.getUsername() + "!", SwingConstants.CENTER);
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 20));
        lblWelcome.setForeground(new Color(0, 35, 102));
        centerPanel.add(lblWelcome);

        add(centerPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createMetricCard(String title, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(new Color(15, 169, 88), 2));
        panel.setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel(title, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(0, 35, 102));
        panel.add(lblTitle, BorderLayout.NORTH);

        JLabel lblValue = new JLabel(value, SwingConstants.CENTER);
        lblValue.setFont(new Font("Arial", Font.BOLD, 32));
        lblValue.setForeground(new Color(15, 169, 88));
        panel.add(lblValue, BorderLayout.CENTER);

        return panel;
    }

    private void configureButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(15, 169, 88));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(13, 150, 78));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(15, 169, 88));
            }
        });
    }

    private void navigateToInicio(Usuario usuario) {
        new DashboardView(usuario);
        dispose();
    }

    private void navigateToVendas(Usuario usuario) {
        new VendasView(usuario);
        dispose();
    }

    private void navigateToClientes(Usuario usuario) {
        new ClientesView(usuario);
        dispose();
    }

    private void navigateToEstoque(Usuario usuario) {
        new StockView();
        dispose();
    }

    private void navigateToRelatorios(Usuario usuario) {
        new RelatorioView();
        dispose();
    }

    private void navigateToConfiguracoes(Usuario usuario) {
        new ConfiguracoesView();
        dispose();
    }
}
